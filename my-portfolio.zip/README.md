# Syed Abdul Maarij — Portfolio

A single-page portfolio for a full-stack engineer. Built with Vite, React,
Tailwind CSS, Framer Motion, and a three.js hero.

## Getting started

```bash
npm install
npm run dev      # start the dev server
npm run build    # production build -> dist/
npm run preview  # preview the production build
```

## Contact form (Web3Forms)

The contact form sends real emails with **no backend** using
[Web3Forms](https://web3forms.com).

1. Go to https://web3forms.com, enter your email, and copy the **access key**
   they send you (no account required).
2. Copy `.env.example` to `.env` and set the key:
   ```
   VITE_WEB3FORMS_KEY=your_access_key
   ```
3. Restart `npm run dev` (or redeploy). Submissions arrive in your inbox.

> Without a key set, the form falls back to opening the visitor's email client.

## Before you deploy

- Replace the placeholder domain `https://syed-abdul-maarij.vercel.app/` with
  your real domain in `index.html` (canonical + Open Graph tags), `public/robots.txt`,
  and `public/sitemap.xml` so link previews and SEO point to the right place.
- On Vercel, add `VITE_WEB3FORMS_KEY` as an Environment Variable.

## Tech

React 19 · Vite · Tailwind CSS · Framer Motion · three.js · react-icons
